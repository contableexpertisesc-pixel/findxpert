============================================
  FINDXPERT — INSTRUCCIONES WINDOWS
============================================

PROBLEMA DETECTADO:
  Estás abriendo el archivo index.html directamente.
  ESO NO FUNCIONA. Necesitas ejecutar el servidor.

SOLUCIÓN (2 pasos):

  PASO 1: Doble clic en:
          INICIAR_FINDXPERT.bat

  PASO 2: Cuando veas "SERVIDOR ACTIVO",
          el navegador se abre solo en:
          http://localhost:5050

============================================
CUENTAS DE DEMO (ya incluidas):
  demo@findxpert.com    / Demo1234!
  admin@findxpert.com   / Admin1234!
============================================

REQUISITO: Python instalado.
  Descarga en: https://python.org
  Al instalar, marca "Add Python to PATH"

============================================
