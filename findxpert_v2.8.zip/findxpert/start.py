#!/usr/bin/env python3
"""
FindXpert v2.1 — Script de inicio
Ejecutar: python start.py
"""
import os, sys, subprocess, secrets, socket, webbrowser, time, threading

PORT = int(os.environ.get('PORT', 5050))

# ── Banner ────────────────────────────────────────────────────────────────────
print()
print("  ╔══════════════════════════════════════════╗")
print("  ║    FindXpert v2.1 — Xpert Labs LLC      ║")
print("  ╚══════════════════════════════════════════╝")
print()

# ── Verificar Python ──────────────────────────────────────────────────────────
if sys.version_info < (3, 8):
    print("  ❌ Requiere Python 3.8 o superior")
    print(f"     Tienes Python {sys.version.split()[0]}")
    sys.exit(1)
print(f"  ✅ Python {sys.version.split()[0]}")

# ── Verificar puerto disponible ───────────────────────────────────────────────
def port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

if port_in_use(PORT):
    print(f"  ⚠️  Puerto {PORT} en uso — probando {PORT+1}...")
    PORT += 1
    if port_in_use(PORT):
        print(f"  ❌ Puerto {PORT} también en uso.")
        print(f"     Cierra la otra aplicación o usa: PORT=5052 python start.py")
        sys.exit(1)

# ── Instalar dependencias ─────────────────────────────────────────────────────
print("  📦 Verificando dependencias...")
try:
    subprocess.check_call(
        [sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt', '-q'],
        stderr=subprocess.DEVNULL
    )
    print("  ✅ Dependencias OK")
except subprocess.CalledProcessError:
    print("  ❌ Error instalando dependencias")
    print("     Ejecuta manualmente: pip install -r requirements.txt")
    sys.exit(1)

# ── Crear .env si no existe ───────────────────────────────────────────────────
if not os.path.exists('.env'):
    key = secrets.token_hex(32)
    with open('.env', 'w') as f:
        f.write(f"SECRET_KEY={key}\n")
        f.write("DATABASE_URL=sqlite:///findxpert.db\n")
        f.write("ANTHROPIC_API_KEY=\n")
        f.write("FLASK_ENV=development\n")
        f.write(f"PORT={PORT}\n")
    print(f"  ✅ .env creado con SECRET_KEY segura")
else:
    print("  ✅ .env existe")

os.makedirs('uploads', exist_ok=True)

# ── Info final ────────────────────────────────────────────────────────────────
url = f"http://localhost:{PORT}"
print()
print(f"  ┌─────────────────────────────────────────┐")
print(f"  │  🌐  {url:<35} │")
print(f"  │  📧  demo@findxpert.com / Demo1234!     │")
print(f"  │  🔑  admin@findxpert.com / Admin1234!   │")
print(f"  │  👋  Ctrl+C para detener                │")
print(f"  └─────────────────────────────────────────┘")
print()

# ── Abrir browser automáticamente (después de 2s) ─────────────────────────────
def open_browser():
    time.sleep(2.5)
    try:
        webbrowser.open(url)
    except Exception:
        pass

threading.Thread(target=open_browser, daemon=True).start()

# ── Arrancar Flask ────────────────────────────────────────────────────────────
os.environ['PORT'] = str(PORT)
os.environ.setdefault('FLASK_ENV', 'development')

os.execv(sys.executable, [sys.executable, 'app.py'])
