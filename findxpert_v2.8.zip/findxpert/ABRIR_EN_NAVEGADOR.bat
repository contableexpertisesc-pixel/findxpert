@echo off
:: Si Flask ya está corriendo, este bat solo abre el navegador
start http://localhost:5050
