@echo off
title FindXpert v2.1 — Iniciando...
color 0A
cls

echo.
echo  ==========================================
echo    FindXpert v2.1 - Xpert Labs LLC
echo  ==========================================
echo.

:: Ir a la carpeta donde está este .bat
cd /d "%~dp0"

:: Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python no encontrado.
    echo.
    echo  Instala Python desde: https://python.org
    echo  IMPORTANTE: marca la casilla "Add Python to PATH"
    echo.
    pause
    start https://python.org/downloads
    exit /b 1
)

echo  Python encontrado OK
echo.

:: Instalar dependencias
echo  Instalando dependencias ^(solo la primera vez^)...
python -m pip install flask flask-sqlalchemy flask-login flask-limiter flask-wtf werkzeug python-dotenv --quiet
echo  Dependencias OK
echo.

:: Crear .env si no existe
if not exist .env (
    echo  Creando configuracion...
    python -c "import secrets; f=open('.env','w'); f.write('SECRET_KEY='+secrets.token_hex(32)+'\nDATABASE_URL=sqlite:///findxpert.db\nANTHROPIC_API_KEY=\nFLASK_ENV=development\nPORT=5050\n'); f.close()"
    echo  Configuracion OK
)

:: Crear carpeta uploads
if not exist uploads mkdir uploads

:: Abrir browser automaticamente despues de 3 segundos
echo  Abriendo navegador en http://localhost:5050 ...
start /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:5050"

echo.
echo  ==========================================
echo   SERVIDOR ACTIVO en http://localhost:5050
echo  ------------------------------------------
echo   Demo:  demo@findxpert.com / Demo1234!
echo   Admin: admin@findxpert.com / Admin1234!
echo  ------------------------------------------
echo   Presiona Ctrl+C para detener
echo  ==========================================
echo.

:: Iniciar Flask
python app.py

pause
