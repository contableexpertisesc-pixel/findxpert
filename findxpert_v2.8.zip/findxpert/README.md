# FindXpert v2.0 — Xpert Labs LLC
Sistema fiscal para self-employed hispanos en USA · IRS 2025 · Flask + SQLite

## Inicio rápido (3 pasos)

### 1. Instalar
```bash
pip install -r requirements.txt
```

### 2. Ejecutar
```bash
python start.py
```

### 3. Abrir navegador
```
http://localhost:5000
```

## Cuentas de demo (pre-cargadas automáticamente)

| Email | Password | Rol |
|-------|----------|-----|
| demo@findxpert.com | Demo1234! | usuario |
| admin@findxpert.com | Admin1234! | superadmin |

## Con IA real (opcional)
Edita `.env` y agrega tu API key de Anthropic:
```
ANTHROPIC_API_KEY=sk-ant-...
```
Sin API key: el scan de recibos usa datos de demo automáticamente.

## API endpoints principales
- POST /api/register — crear cuenta
- POST /api/login — iniciar sesión
- GET  /api/dashboard — resumen + impuestos IRS 2025
- GET/POST /api/incomes — ingresos
- GET/POST /api/receipts — gastos/recibos
- POST /api/receipts/scan — escanear recibo con IA
- POST /api/tax/calculate — calculadora IRS 2025
- GET  /api/reports/summary — reporte Schedule C

## Seguridad implementada
- Anti-IDOR: cada query filtra por user_id del session
- Rate limiting: 5 intentos/min en login
- Passwords: pbkdf2:sha256 con salt de 16 bytes
- Audit log: cada acción queda registrada
- Headers: X-Frame-Options, nosniff, XSS-Protection

## Deploy Railway
```bash
railway login && railway init && railway up
```
Variables requeridas: SECRET_KEY, DATABASE_URL (PostgreSQL), FLASK_ENV=production

---
⚖️ FindXpert organiza tus finanzas. No es asesoría fiscal.
Consulta un CPA antes de presentar tu declaración. IRS Circular 230 aplica.
