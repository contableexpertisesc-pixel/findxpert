============================================================
  FINDXPERT — DEPLOY EN INTERNET (Railway.app)
  Para que funcione en xpertlabsolutions.com
============================================================

IMPORTANTE: El hosting de Corporate Tools es WordPress.
FindXpert es Python/Flask y NO se puede instalar en WordPress.
Usa Railway (gratis, soporta Python).

------------------------------------------------------------
PASO 1: Crear cuenta en Railway (2 minutos)
------------------------------------------------------------
1. Ve a https://railway.app
2. Click "Login with GitHub"
3. Crea cuenta de GitHub si no tienes (gratis)

------------------------------------------------------------
PASO 2: Subir FindXpert a GitHub
------------------------------------------------------------
1. Ve a https://github.com/new
2. Nombre del repo: findxpert
3. Privado (Private) — tus datos fiscales
4. Click "Create repository"

En tu computadora (terminal en la carpeta findxpert):
  git init
  git add .
  git commit -m "FindXpert v2.1"
  git remote add origin https://github.com/TU_USUARIO/findxpert.git
  git push -u origin main

------------------------------------------------------------
PASO 3: Deploy en Railway
------------------------------------------------------------
1. En railway.app → New Project → Deploy from GitHub repo
2. Selecciona "findxpert"
3. Railway detecta Python automáticamente

Variables de entorno (Settings → Variables):
  SECRET_KEY    = [genera con: python -c "import secrets; print(secrets.token_hex(32))"]
  DATABASE_URL  = [Railway lo da automáticamente si agregas PostgreSQL]
  FLASK_ENV     = production
  ANTHROPIC_API_KEY = sk-ant-... (opcional)

4. Click Deploy → espera 2 minutos
5. Railway te da URL: findxpert-production.up.railway.app

------------------------------------------------------------
PASO 4: Conectar tu dominio getfindxpert.com
------------------------------------------------------------
En Railway → Settings → Domains → Add Custom Domain
  Escribe: app.getfindxpert.com (o getfindxpert.com)
  Railway te da los DNS records

En tu registrador de dominio agrega:
  CNAME  app  →  [lo que Railway indique]

------------------------------------------------------------
COSTO:
  Railway: $5/mes (plan Hobby) o gratis con limitaciones
  Mejor que pagar hosting WordPress que no soporta Python
============================================================
